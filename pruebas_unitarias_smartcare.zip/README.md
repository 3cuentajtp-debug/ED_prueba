# SmartCare CNS

**Sistema de Gestión de Citas Médicas y Atención Médica en la Caja Nacional de Salud (CNS)**

Aplicación web desarrollada con **PHP** y **MySQL** para la gestión de citas médicas, con paneles diferenciados por rol y un chatbot opcional con inteligencia artificial.

---

## Tabla de contenidos

- [Características](#características)
- [Tecnologías](#tecnologías)
- [Requisitos previos](#requisitos-previos)
- [Instalación](#instalación)
- [Credenciales de prueba](#credenciales-de-prueba)
- [Modo demostración](#modo-demostración)
- [Chatbot con IA (opcional)](#chatbot-con-ia-opcional)
- [Estructura relevante del proyecto](#estructura-relevante-del-proyecto)
- [Pruebas unitarias](#pruebas-unitarias)
- [Integrantes](#integrantes)

---

## Características

- Inicio de sesión con acceso diferenciado por rol: **Paciente, Médico, Administrador y Recepcionista**.
- Registro de nuevos pacientes con validación de datos (CI, celular, edad mínima de 18 años y contraseña).
- Gestión de citas médicas y atención médica: agendar, editar, atender y registrar diagnósticos.
- Botón **Volver** propio del sitio en todos los paneles: recuerda las últimas páginas visitadas y regresa a la anterior sin usar el botón del navegador.
- **Reportes clínicos del médico** con filtros por rango de fechas y por paciente, y exportación a PDF.
- **Reporte de fichas de recepción** con filtros por nombre o CI, médico, rango de fechas y tipo de paciente (nuevo o antiguo). El PDF respeta los filtros y solo se abre con sesión de recepcionista.
- Base de datos normalizada (3FN) con 17 tablas, llaves foráneas y datos de prueba listos para usar.
- Contraseñas almacenadas cifradas con `password_hash`.
- Chatbot con IA local (opcional) mediante Ollama.

## Tecnologías

| Componente | Tecnología |
|---|---|
| Backend | PHP |
| Frontend | HTML, CSS, JavaScript, Bootstrap 5 y Bootstrap Icons |
| Control de versiones | Git y GitHub |
| Base de datos | MySQL |
| Servidor local | XAMPP (Apache + MySQL) |
| Chatbot (opcional) | Ollama + modelo `qwen3:4b` |

## Requisitos previos

- [XAMPP](https://www.apachefriends.org/) instalado (incluye Apache, MySQL y phpMyAdmin).
- Un navegador web actualizado.
- [Git](https://git-scm.com/) (solo si clonas el repositorio).
- *(Opcional)* [Ollama](https://ollama.com/) para el chatbot.

## Instalación

### 1. Obtener el proyecto

Abre una terminal (CMD, PowerShell o Git Bash) y ejecuta:

```bash
cd C:\xampp\htdocs
git clone https://github.com/Valerfy/proyecto_smartcare.git
cd proyecto_smartcare
```

Para actualizar tu copia local más adelante:

```bash
git pull origin main
```

> Si prefieres descargar el repositorio como ZIP, extráelo y **renombra la carpeta a exactamente `proyecto_smartcare`** (GitHub la nombra `proyecto_smartcare-main`; si no la renombras, las rutas de abajo no funcionarán).

### 2. Ubicar el proyecto en XAMPP

La carpeta `proyecto_smartcare` debe quedar dentro de:

```
C:\xampp\htdocs\
```

Si clonaste con los comandos del paso anterior, ya está en el lugar correcto. Si descargaste el ZIP, muévela manualmente a esa ruta.

### 3. Iniciar los servicios

Abre el **Panel de Control de XAMPP** e inicia **Apache** y **MySQL**.

### 4. Crear la base de datos

1. Abre [http://localhost/phpmyadmin/](http://localhost/phpmyadmin/) en el navegador.
2. Ve a la pestaña **Importar** y selecciona el archivo:

   ```
   proyecto_smartcare/database/cns_sistema_v2.sql
   ```

Este archivo crea la base de datos y carga los datos de prueba necesarios.

### 5. Verificar la conexión

Revisa que las credenciales de conexión sean correctas en:

```
proyecto_smartcare/config/conexion.php
```

### 6. Abrir el sistema

Ingresa desde el navegador a:

[http://localhost/proyecto_smartcare/public/](http://localhost/proyecto_smartcare/public/)

Se mostrará la pantalla de inicio de sesión (Login).

## Credenciales de prueba

Inicia sesión con cada cuenta para comprobar los distintos paneles y sus funcionalidades. Los datos corresponden a los registros de prueba incluidos en la base de datos importada.

| Rol | Correo electrónico | Contraseña |
|---|---|---|
| Paciente | `valerofernandezmatias@gmail.com` | `1234` |
| Médico | `anuar.vargas@cns.org.bo` | `1234` |
| Administrador | `matias.valero@cns.com` | `1234` |
| Recepcionista | `sofia.loayza@cns.rec.bo` | `1234` |

> Estas credenciales son solo para pruebas en entorno local.

## Chatbot con IA (opcional)

1. Instala [Ollama](https://ollama.com/).
2. Descarga el modelo:

   ```bash
   ollama pull qwen3:4b
   ```
3. Asegúrate de que el servicio de Ollama esté en ejecución.

> **Nota:** el resto del sistema funciona con normalidad sin instalar ni configurar el chatbot.

## Estructura relevante del proyecto

```
proyecto_smartcare/
├── assets/                   # CSS, JavaScript e imágenes (fotos de perfil)
├── config/
│   └── conexion.php          # Conexión a la base de datos
├── controllers/              # Lógica de cada rol (Auth, Paciente, Medico, Admin, Helper, Chatbot)
├── database/
│   └── cns_sistema_v2.sql    # Script de la base de datos y datos de prueba
├── models/                   # Acceso a datos (Usuario, Cita, Historial, Reportes...)
├── tests/                    # Pruebas unitarias (se ejecutan por terminal)
├── public/                   # Punto de entrada: enrutador y Login
├── views/
│   ├── admin/                # Panel del administrador
│   ├── auth/                 # Inicio de sesión y registro
│   ├── components/
│   │   └── volver.php        # Botón "Volver" compartido por todos los roles
│   ├── helper/               # Panel del recepcionista
│   ├── medico/               # Panel del médico
│   └── paciente/             # Panel del paciente
└── README.md
```

## Pruebas unitarias

Las pruebas están en la carpeta `tests/`, en archivos aparte del código del sistema. Cada prueba ejecuta la función, compara el resultado con lo esperado e imprime en la terminal si fue **exitosa** y los **datos que devolvió**. No necesitan navegador ni base de datos.

| Archivo | Qué prueba |
|---|---|
| `tests/test_registro_paciente.php` | Validación del registro de pacientes (nombre, CI, celular, edad mínima de 18 años, correo, contraseña, términos) |
| `tests/test_login.php` | Inicio de sesión: validaciones, contraseña incorrecta, usuario desactivado, bloqueo tras 5 intentos y redirección por rol |
| `tests/test_filtros_y_horarios.php` | Funciones reales de los modelos: filtros del reporte de recepción, generación de horarios de 30 min y separación de antecedentes |
| `tests/run_all.php` | Ejecuta todas las pruebas y muestra el resumen |

### Cómo ejecutarlas

Abre una terminal en la carpeta del proyecto y ejecuta:

```bash
php tests/run_all.php
```

En XAMPP (Windows), si `php` no está en el PATH:

```bash
C:\xampp\php\php.exe tests\run_all.php
```

Para ejecutar solo un archivo: `php tests/test_login.php`. Si los acentos se ven mal en CMD, ejecuta antes `chcp 65001`.

Ejemplo de salida:

```
[OK]    PRUEBA EXITOSA: Menor de edad es rechazado
        Devuelve: {"fecha_nac":"Debes ser mayor de 18 años."}

 RESULTADO: 43 pruebas | 43 exitosas | 0 fallidas
```

## Integrantes

| Integrante | Rol | Usuario de GitHub |
|---|---|---|
| Matías Valero Fernández | COMPLETAR ROL | [@Valerfy](https://github.com/Valerfy) |
| Juan Anuar Vargas Claros | COMPLETAR ROL | [@Anufox](https://github.com/Anufox) |
| Jhonatan Torrez Pocoma | COMPLETAR ROL | [@3cuentajtp-debug](https://github.com/3cuentajtp-debug) |
